package br.com.alura.forum.controller;


import java.net.URI;
import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import br.com.alura.forum.controller.dto.TopicoDto;
import br.com.alura.forum.controller.form.AtualizacaoForm;
import br.com.alura.forum.controller.form.TopicoForm;
import br.com.alura.forum.modelo.Topico;
import br.com.alura.forum.repository.CursoRepository;
import br.com.alura.forum.repository.TopicoRepository;

@RestController // ao declarar essa notação,não precisamos ficar informando o @responsebody
@RequestMapping("/topicos")  // Notação para indicar o caminho mapeado para requisição ex: http://localhost:8080/topicos
public class TopicosController {

	@Autowired // fornece controle sobre onde e como a ligação entre os beans deve ser realizada
	private TopicoRepository topicorepository;
	@Autowired
	private CursoRepository cursoRepository;

		@GetMapping // indica que a será uma requisição para consultar e devolver para a URL as informações do banco de dados
		public List<TopicoDto> lista(String nomeCurso) {
		
		if (nomeCurso == null) {
			List<Topico> topicos = topicorepository.findAll();
			return TopicoDto.converter(topicos);
		}else {
				List<Topico> topicos = topicorepository.findByCursoNome(nomeCurso); // aqui está filtrando pelo nome do curso
				return TopicoDto.converter(topicos);
			  }
	}
		@PostMapping
		@Transactional // anotação para efetuar o commit no banco após término da execução
		// @valid serve para utilizar o metodo ben validation para validar os atributos passados no form para cadastrado
		public ResponseEntity<TopicoDto> Cadastrar(@RequestBody @Valid TopicoForm form, UriComponentsBuilder uriBuilder) {
			Topico topico = form.converter(cursoRepository);
			topicorepository.save(topico);
			
			URI uri = uriBuilder.path("/topicos/{id}").buildAndExpand(topico.getId()).toUri();
			return ResponseEntity.created(uri).body(new TopicoDto(topico)); //  ideia é devolver o 201, com cabeçalho location e corpo da resposta sendo uma representação do recurso que acabou de ser criado. Agora só falta fazer o teste.
		}
	
		@GetMapping("/{id}") // indica que eu irei consultar o código passado na url
		public ResponseEntity<TopicoDto> pesquisar(@PathVariable long id) { // @pathvariable indica que eu estou tratando o conteudo do /{id} como variável, se não interpretaria com "?" numero
			java.util.Optional<Topico> topico = topicorepository.findById(id);
			if (topico.isPresent()) {
				return ResponseEntity.ok(new TopicoDto(topico.get()));
				
			}
			return ResponseEntity.notFound().build();
		}
		
		@PutMapping("/{id}") // Anotação serve para atualizar informação
		@Transactional // anotação para efetuar o commit no banco após término da execução
		
		// Envia mensagem para atualização no banco validando o conteúdo recebido da URL
		public ResponseEntity<TopicoDto> Atualizar(@PathVariable long id, @RequestBody @Valid AtualizacaoForm form) 
		//Criamos um novo controller de formulário para não misturar com o form de cadastro, deixando seprado caso o cliente queira trabalhar campos distintos para cada ação do banco
		{
			java.util.Optional<Topico> optional = topicorepository.findById(id);
			if (optional.isPresent()) {
			
			Topico topico = form.Atualizar(id, topicorepository);
			// Irá retornar a mensagem gravada no banco para a URL
			return ResponseEntity.ok(new TopicoDto(topico));
			}
            return ResponseEntity.notFound().build();
		}
		
		@DeleteMapping("/{id}") // Anotação serve para remover uma informação passada pela URL
		@Transactional // anotação para efetuar o commit no banco após término da execução
		
		public ResponseEntity<?> Deletar(@PathVariable long id) // @pathvariable indica que eu estou tratando o conteudo do /{id} como variável, se não interpretaria com "?" numero
		{
			java.util.Optional<Topico> optional = topicorepository.findById(id);
			if (optional.isPresent()) {
				// invoca o método encapsulado da JPA para deletar no banco de dados
				topicorepository.deleteById(id);
				//retorna status da requisição
				return ResponseEntity.ok().build();
			}
               return ResponseEntity.notFound().build();

		}
		
}

