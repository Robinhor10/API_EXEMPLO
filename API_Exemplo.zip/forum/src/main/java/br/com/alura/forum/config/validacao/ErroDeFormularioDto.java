package br.com.alura.forum.config.validacao;

public class ErroDeFormularioDto {

	private String Campo;
	private String erro;
	
	
	public ErroDeFormularioDto(String campo, String erro) {
		super();
		Campo = campo;
		this.erro = erro;
	}


	public String getCampo() {
		return Campo;
	}


	public String getErro() {
		return erro;
	}
	
	
	
	
}
