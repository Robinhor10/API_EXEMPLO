package br.com.alura.forum.controller;

public class topicoPesquisado {

}
